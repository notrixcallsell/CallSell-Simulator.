# CallSell Simulator - projet Android

Ce dossier prépare l'enrobage Android du prototype web. Il ne contient pas encore un APK compilé.

## Prérequis
- Node.js et npm
- Android Studio avec Android SDK
- Une connexion Internet pour installer Capacitor

## Générer le projet Android
Dans un terminal, depuis ce dossier :

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio s'ouvre. Pour créer un APK de test :
1. Attendez la synchronisation Gradle.
2. Ouvrez le menu **Build**.
3. Choisissez **Build Bundle(s) / APK(s)** puis **Build APK(s)**.
4. Android Studio indiquera où se trouve l'APK généré.

## Nom et identifiant
- Nom affiché : CallSell Simulator
- Identifiant Android : com.callsell.simulator

## À savoir
- Le jeu reste un prototype local : dialogues à règles simples, pas encore de véritable IA.
- La sauvegarde est locale à l'application.
- Les délais de livraison sont calculés à partir de l'heure réelle et se mettent à jour au retour dans le jeu.
- Les fonctionnalités vocales dépendent du support Android/WebView et des autorisations.
- Il n'y a pas encore de comptes, serveur, multijoueur, notifications de livraison natives ou économie synchronisée.
- Ne placez jamais une clé API secrète dans les fichiers `www`.

L'icône vectorielle de base est fournie dans `assets/icon.svg`. Pour une icône Android complète, importez-la dans Android Studio via Image Asset.
